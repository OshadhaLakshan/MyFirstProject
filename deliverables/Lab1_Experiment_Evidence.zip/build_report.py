from pathlib import Path
import html
import json

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

ROOT = Path('/workspace/lab1-work')
OUT = Path('/workspace/outputs')
OUT.mkdir(exist_ok=True)
data = json.loads((ROOT / 'evidence/results.json').read_text())
pdfmetrics.registerFont(TTFont('LabSans', '/usr/share/fonts/truetype/open-sans/OpenSans-Regular.ttf'))
pdfmetrics.registerFont(TTFont('LabSansBold', '/usr/share/fonts/truetype/open-sans/OpenSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('LabMono', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='LabTitle', fontName='LabSansBold', fontSize=18, leading=22, textColor=colors.HexColor('#16324f'), spaceAfter=12))
styles.add(ParagraphStyle(name='LabHeading', fontName='LabSansBold', fontSize=11.5, leading=15, textColor=colors.HexColor('#16324f'), spaceBefore=10, spaceAfter=5))
styles.add(ParagraphStyle(name='LabBody', fontName='LabSans', fontSize=9.6, leading=13, spaceAfter=7))
styles.add(ParagraphStyle(name='LabSmall', fontName='LabSans', fontSize=8.5, leading=11, spaceAfter=6))
styles.add(ParagraphStyle(name='LabCell', fontName='LabSans', fontSize=9, leading=12))
styles.add(ParagraphStyle(name='LabCode', fontName='LabMono', fontSize=8.3, leading=11, spaceAfter=4))
story, markdown = [], []


def para(text, style='LabBody'):
    story.append(Paragraph(html.escape(text), styles[style]))
    markdown.append(text + '\n')


def heading(text):
    para(text, 'LabHeading')


def table(headers, rows, widths):
    cells = [[Paragraph(html.escape(str(v)), styles['LabCell']) for v in row] for row in [headers, *rows]]
    t = Table(cells, colWidths=widths, repeatRows=1, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e8eef5')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LINEBELOW', (0, 0), (-1, 0), 0.6, colors.HexColor('#95a7ba')),
        ('LINEBELOW', (0, 1), (-1, -1), 0.3, colors.HexColor('#d9e1ea')),
        ('LEFTPADDING', (0, 0), (-1, -1), 7),
        ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    story.extend([t, Spacer(1, 7)])
    markdown.append('| ' + ' | '.join(headers) + ' |\n| ' + ' | '.join(['---'] * len(headers)) + ' |')
    markdown.extend('| ' + ' | '.join(str(v) for v in row) + ' |' for row in rows)
    markdown.append('')


def page():
    story.append(PageBreak())
    markdown.append('\n---\n')


para('SCS2314 Lab 1', 'LabTitle')
para('Multithreaded Chat Server with Java Sockets', 'LabHeading')
para('Student index: ____________________     Date: 13 October 2026', 'LabSmall')
heading('Method and implementation')
para('The supplied starter code was completed and tested in a Linux cloud environment using Temurin JDK 21.0.8. The experiments used localhost:5000. Compilation used javac --release 21; the final Maven build was also checked. Eclipse was not used. TCP peers were driven by an automated harness, alongside the supplied ChatClient, CounterDemo and LoadTester programs. All values below are measured results, not example values.')
para('Separate unsafe, list-fixed and fully fixed source versions were compiled for Part 4. A fresh server was started for each load-test run to isolate failures. The submitted ChatServer uses a ten-worker pool by default; its optional --thread-per-client mode retains the Part 4 workflow.')
heading('Part 1: Single-threaded echo server')
para('The first client received its welcome and an echo reply. A second TCP connection succeeded, but received neither a welcome nor an echo while the first client remained connected. After the first client sent bye, the second received its welcome and echo: second message. The main thread was blocked in handle(), reading the first client, and could not return to accept(). A successful TCP connection therefore did not mean the application was already serving that client.')
heading('Parts 2 and 3: Concurrent echo and chat')
para('ThreadedEchoServer returned the expected echo replies to three simultaneously open clients. Server logs identified three different workers: Thread-0, Thread-2 and Thread-1. Each worker blocks waiting for its own client; the main thread continues accepting connections.')
para('The five ClientHandler TODOs register clients, broadcast messages, implement /list, count chat messages and remove disconnected clients. Three chat peers verified joins, delivery to all recipients, online: Alice, Bob, Carol, stats: 1 messages and departure on /quit. The provided Java ChatClient also sent a message successfully. A generic TCP peer could participate because the protocol is UTF-8 text lines, independent of the client implementation language.')
heading('Part 4a: Counter experiment')
para('Expected total in every run: 50 threads x 100,000 increments = 5,000,000.', 'LabSmall')
table(['Run', 'Unsafe actual', 'Lost updates', 'AtomicInteger actual'], [
    [i + 1, f"{r['actual']:,}", f"{r['lost']:,}", f"{data['part4a']['fixed'][i]['actual']:,}"]
    for i, r in enumerate(data['part4a']['original'])
], [42, 142, 142, 185])
para('Think - lost update: count++ reads, adds and writes. If two threads both read 10, each computes 11 and writes 11; two increments produce only one increase. volatile provides visibility and ordering, but the compound increment is still not atomic. AtomicInteger.incrementAndGet() makes each increment atomic, and get() reads the result. All three corrected runs produced 5,000,000 with zero lost updates.')

page()
para('Part 4b: Chat server under load', 'LabTitle')
para('Each test used the supplied default LoadTester: 50 clients x 1,000 messages, with five churn threads repeatedly joining and leaving. Expected count per run: 50,000. The server count is the difference between /stats readings before and after the run; commands and join/leave announcements are not counted.')
rows = []
for name, label, exception in [
    ('unsafe', 'Unsafe list and counter', 'CME in all runs; NPE also in run 1'),
    ('list-fixed', 'List fixed only', 'None'),
    ('fixed', 'List and counter fixed', 'None'),
]:
    runs = data['part4b'][name]
    values = [f"{r['counted']:,}" if r['counted'] is not None else 'No reply' for r in runs]
    rows.append([label, *values, exception])
table(['Version', 'Run 1', 'Run 2', 'Run 3', 'Server exceptions'], rows, [133, 64, 64, 64, 186])
para('CME = ConcurrentModificationException; NPE = NullPointerException. "No reply" is an unavailable count, not zero. In unsafe run 1, /stats failed to reply and all 50 load clients reported write errors. Runs 2 and 3 reported 46 and 47 clients with write errors, respectively. These were failed experiments, despite LoadTester returning exit code 0.', 'LabSmall')
heading('Observed effect of each fix')
para('The unsafe ArrayList was modified while broadcast() iterated over it. ConcurrentModificationException terminated client handlers; run 1 also logged a null list entry in broadcast(), causing NullPointerException. Affected handlers closed their sockets, so many messages were never processed and the statistics request could fail.')
para('CopyOnWriteArrayList removed the iteration exceptions and client write errors, but the plain integer still lost 79, 98 and 66 increments. After replacing messageCount with AtomicInteger and updating both incrementAndGet() and get(), all three tests counted 50,000, with no exceptions or tester warnings. Their measured durations were 4,243 ms, 4,380 ms and 3,968 ms. A further test of the actual submitted source in --thread-per-client mode also counted 50,000 with zero lost messages.')
heading('Think: Why do exceptions reduce the count so much?')
para('The read loop runs inside a client handler. An unchecked exception exits that loop and triggers finally, which disconnects the client. The worker stops reading the remaining queued messages, and later writes from that client can fail. This loses processing of whole message sequences, in addition to any increments lost through counter races.')
heading('Think: Why does a successful test not prove correctness?')
para('A race depends on the timing and interleaving of threads. A particular run may avoid overlapping increments and appear correct, especially when other work delays the threads. Other CPU loads or client timing can expose it. Repeated testing provides evidence, but correctness also requires a concurrency argument: atomic increments and safe list iteration remove the specific unsafe operations.')
heading('Think: Why synchronize send(), and can message order differ?')
para('PrintWriter.println() already locks internally, so a single-line send normally remains intact. Declaring send() synchronized makes the per-client serialization rule explicit and protects future changes that might perform several writer operations. It does not impose a total order across all clients. Two broadcasts can interleave their visits to different client handlers, allowing one recipient to receive A then B while another receives B then A. A single broadcast dispatcher or sequencing protocol would be needed for a consistent global order.')

page()
para('Parts 5 and 6: Capacity and failure', 'LabTitle')
heading('Part 5: Ten-worker thread pool')
para('ChatServer creates Executors.newFixedThreadPool(10) before its accept loop and submits each ClientHandler to it. With LoadTester --clients 12 --hold, exactly ten hold handlers were logged as connected before release. A thirteenth TCP peer connected and sent /list, but received no response while all workers were occupied. After Enter released the hold clients, both queued hold handlers started and the waiting peer received online: hold10, hold11, WaitingClient. The hold program exited successfully.')
heading('Think: Thread-per-client versus a fixed pool')
para('One thread per client is simple and lets every connected client have a handler immediately, but idle blocking clients still consume thread resources. Creating 100,000 platform threads can exhaust memory or operating-system limits and adds scheduling overhead. A fixed pool caps active workers, but long-lived idle clients occupy all ten slots and prevent queued clients from being served. The default fixed pool has an unbounded queue: pending sockets and tasks still consume memory. A bounded ThreadPoolExecutor queue, explicit admission limit and rejection handler that closes rejected sockets could refuse excess work. This lab demonstrates the pool limit; it does not implement that additional production policy.')
heading('Part 6: Abrupt client and server failure')
para('Alice, Bob and the supplied Java ChatClient named CrashClient were connected. CrashClient was forcibly killed without /quit. Both survivors received * CrashClient left, /list returned online: Alice, Bob, and both still exchanged a subsequent message. This verifies cleanup on unexpected process termination rather than only the normal quit path. disconnect() runs from finally, removes the registered handler and closes the socket in its own finally block.')
para('Stopping the server closed the remaining TCP connections. In a separate check, the supplied Java ChatClient printed -- disconnected from server -- and exited. These observations cover detectable local socket closure; they do not establish immediate detection of every remote network outage.')
heading('Think: Can the server distinguish a crashed client from a quiet one?')
para('An orderly TCP close produces end-of-stream and some failures produce an I/O error. However, a silent network failure or unreachable machine can leave a connection apparently open, with readLine() waiting just as it would for a quiet client. Absence of messages alone cannot distinguish the cases reliably. Application heartbeats and read deadlines can flag a client as unresponsive, but a timeout is a suspicion of failure: delay or congestion can also trigger it. Cleanup must run whenever disconnection is detected, and other clients should remain usable.')
heading('Build and reproduce the submitted code')
para('Use JDK 21. From the directory containing pom.xml, run mvn compile. For the pool demonstration, start the default server:', 'LabSmall')
para('java -cp target/classes chat.ChatServer 5000', 'LabCode')
para('For Part 4 load testing, use a separate server run with:', 'LabSmall')
para('java -cp target/classes chat.ChatServer 5000 --thread-per-client', 'LabCode')
para('java -cp target/classes chat.LoadTester', 'LabCode')
para('Stop the previous server before starting another on port 5000. Using the ten-worker pool for the 50-client stress experiment changes the experiment: clients queue behind occupied workers. CounterDemo in the submission is the corrected atomic version. Unsafe and intermediate measurements came from separate preserved experiment versions.', 'LabSmall')
heading('Submission contents and scope')
para('The submission ZIP contains this three-page report, src/ (including the original echo server, ThreadedEchoServer and completed chat classes), and the supplied pom.xml. It excludes target/. The original Git repository was left unchanged. Measurements were generated by automated cloud execution; they were not collected through Eclipse or manually on the student\'s laptop. Add the student index and rename the ZIP before submission.', 'LabSmall')


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#c7d3df'))
    canvas.line(42, 39, A4[0] - 42, 39)
    canvas.setFont('LabSans', 8)
    canvas.setFillColor(colors.HexColor('#53677b'))
    canvas.drawString(42, 25, 'SCS2314 | Lab 1 | Java sockets and concurrency')
    canvas.drawRightString(A4[0] - 42, 25, str(doc.page))
    canvas.restoreState()


pdf = OUT / 'SCS2314_Lab1_Report.pdf'
doc = SimpleDocTemplate(str(pdf), pagesize=A4, rightMargin=42, leftMargin=42, topMargin=36, bottomMargin=52,
                        title='SCS2314 Lab 1 - Multithreaded Chat Server', author='')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
(OUT / 'SCS2314_Lab1_Report.md').write_text('\n'.join(markdown))
print(pdf)
