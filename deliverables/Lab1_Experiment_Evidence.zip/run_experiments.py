from pathlib import Path
import contextlib
import json
import re
import select
import socket
import subprocess
import time

ROOT = Path('/workspace/lab1-work')
JAVA = '/workspace/tools/jdk-21.0.8+9/bin/java'
EVIDENCE = ROOT / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
RESULTS = {'runtime': subprocess.check_output([JAVA, '-version'], stderr=subprocess.STDOUT, text=True).strip()}


def wait_for(predicate, seconds=10):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(0.05)
    raise AssertionError('Timed out waiting for expected condition')


@contextlib.contextmanager
def server(variant, main, label, args=()):
    log = EVIDENCE / (label + '-server.log')
    with log.open('w') as output:
        process = subprocess.Popen([JAVA, '-cp', str(ROOT / variant / 'target/classes'), main, '5000', *args], stdout=output, stderr=subprocess.STDOUT)
        try:
            wait_for(lambda: 'listening on port' in log.read_text())
            yield process, log
        finally:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


class Peer:
    def __init__(self):
        self.socket = socket.create_connection(('localhost', 5000), timeout=5)
        self.buffer = b''

    def send(self, line):
        self.socket.sendall((line + '\n').encode())

    def line(self, timeout=5):
        deadline = time.monotonic() + timeout
        while b'\n' not in self.buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.socket], [], [], remaining)[0]:
                raise TimeoutError('No complete reply')
            part = self.socket.recv(65536)
            if not part:
                raise EOFError('Connection closed')
            self.buffer += part
        line, self.buffer = self.buffer.split(b'\n', 1)
        return line.decode().rstrip('\r')

    def until(self, expected, timeout=5):
        lines = []
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            line = self.line(max(0.01, deadline - time.monotonic()))
            lines.append(line)
            if expected(line):
                return lines
        raise AssertionError('Expected reply not received')

    def quiet(self, timeout=0.4):
        return not self.buffer and not select.select([self.socket], [], [], timeout)[0]

    def close(self):
        self.socket.close()


def echo_tests():
    transcript = []
    with server('original', 'echo.EchoServer', 'part1'):
        a, b = Peer(), None
        try:
            transcript.append('First client: ' + a.line())
            a.send('first message')
            assert a.line() == 'echo: first message'
            b = Peer()
            b.send('second message')
            blocked = b.quiet()
            assert blocked
            transcript.append('Second TCP connection succeeded, but no welcome or echo while first client remained connected.')
            a.send('bye')
            assert a.line() == 'Goodbye'
            transcript.append('After first client sent bye: ' + b.line())
            reply = b.line()
            assert reply == 'echo: second message'
            transcript.append('Second client: ' + reply)
            b.send('bye')
            assert b.line() == 'Goodbye'
        finally:
            a.close()
            if b:
                b.close()
    RESULTS['part1'] = {'passed': True, 'observation': transcript}
    (EVIDENCE / 'part1-observation.txt').write_text('\n'.join(transcript) + '\n')
    with server('submission', 'echo.ThreadedEchoServer', 'part2') as (_, log):
        peers = [Peer() for _ in range(3)]
        try:
            for peer in peers:
                assert peer.line().startswith('Welcome!')
            for n, peer in enumerate(peers):
                peer.send('parallel-' + str(n))
            replies = [peer.line() for peer in peers]
            assert replies == ['echo: parallel-' + str(n) for n in range(3)]
            for peer in peers:
                peer.send('bye')
                assert peer.line() == 'Goodbye'
            workers = re.findall(r'on (Thread-\d+)', log.read_text())
            assert len(set(workers)) == 3
            RESULTS['part2'] = {'passed': True, 'replies': replies, 'worker_threads': workers}
        finally:
            for peer in peers:
                peer.close()
    print('Parts 1 and 2: echo behavior verified', flush=True)


def chat_tests():
    transcript = []
    with server('submission', 'chat.ChatServer', 'part3') as (_, log):
        peers = []
        try:
            for name in ['Alice', 'Bob', 'Carol']:
                peer = Peer()
                peers.append(peer)
                peer.send(name)
                transcript.extend(peer.until(lambda line, name=name: line == '* ' + name + ' joined'))
            peers[0].send('hello everyone')
            for peer in peers:
                transcript.extend(peer.until(lambda line: line == '[Alice] hello everyone'))
            peers[1].send('/list')
            lines = peers[1].until(lambda line: line.startswith('online: '))
            assert lines[-1] == 'online: Alice, Bob, Carol'
            transcript.extend(lines)
            peers[0].send('/stats')
            lines = peers[0].until(lambda line: line.startswith('stats: '))
            assert lines[-1] == 'stats: 1 messages'
            transcript.extend(lines)
            peers[2].send('/quit')
            transcript.extend(peers[0].until(lambda line: line == '* Carol left'))
            peers[0].send('/list')
            lines = peers[0].until(lambda line: line.startswith('online: '))
            assert lines[-1] == 'online: Alice, Bob'
            transcript.extend(lines)
            # Run the provided interactive Java client with actual keyboard input.
            run = subprocess.run([JAVA, '-cp', str(ROOT / 'submission/target/classes'), 'chat.ChatClient', 'localhost', '5000', 'JavaClient'], input='hello from Java\n/quit\n', capture_output=True, text=True, timeout=10)
            assert run.returncode == 0
            wait_for(lambda: 'JavaClient disconnected' in log.read_text())
            transcript.extend(peers[0].until(lambda line: line == '[JavaClient] hello from Java'))
            RESULTS['part3'] = {'passed': True, 'checks': ['three simultaneous clients', 'join', 'broadcast to all', '/list', '/stats', '/quit', 'generic TCP client', 'provided Java ChatClient'], 'java_client_exit': run.returncode}
            (EVIDENCE / 'part3-java-client.log').write_text(run.stdout + run.stderr)
        finally:
            for peer in peers:
                peer.close()
    (EVIDENCE / 'part3-transcript.txt').write_text('\n'.join(transcript) + '\n')
    print('Part 3: protocol and provided Java client verified', flush=True)


def counter_tests():
    counters = {}
    for variant in ['original', 'fixed']:
        runs = []
        for n in range(1, 4):
            run = subprocess.run([JAVA, '-cp', str(ROOT / variant / 'target/classes'), 'chat.CounterDemo'], capture_output=True, text=True, timeout=30)
            (EVIDENCE / f'part4a-{variant}-{n}.log').write_text(run.stdout + run.stderr)
            assert run.returncode == 0
            actual = int(re.search(r'Actual:\s+([\d,]+)', run.stdout).group(1).replace(',', ''))
            if variant == 'fixed':
                assert actual == 5_000_000
            runs.append({'expected': 5_000_000, 'actual': actual, 'lost': 5_000_000 - actual, 'exit': run.returncode})
            print(f'Counter {variant} run {n}: {actual:,}', flush=True)
        counters[variant] = runs
    RESULTS['part4a'] = counters


def load_tests():
    stages = {}
    for variant in ['unsafe', 'list-fixed', 'fixed']:
        runs = []
        for n in range(1, 4):
            label = f'part4b-{variant}-{n}'
            with server(variant, 'chat.ChatServer', label) as (_, log):
                run = subprocess.run([JAVA, '-cp', str(ROOT / variant / 'target/classes'), 'chat.LoadTester'], capture_output=True, text=True, timeout=180)
                (EVIDENCE / (label + '-load.log')).write_text(run.stdout + run.stderr)
                counted = re.search(r'Server counted:\s+([\d,]+)', run.stdout)
                actual = int(counted.group(1).replace(',', '')) if counted else None
                milliseconds = int(re.search(r'Time:\s+([\d,]+) ms', run.stdout).group(1).replace(',', ''))
                errors = log.read_text()
                exception_types = sorted(set(re.findall(r'(?:java\.[\w.]+\.)?(\w+Exception)', errors)))
                warnings = [line for line in run.stdout.splitlines() if any(term in line for term in ['failed to connect', 'write errors', 'read timeout', 'Not finished', 'timed out', 'no /stats reply'])]
                result = {'expected': 50_000, 'counted': actual, 'lost': 50_000 - actual if actual is not None else None, 'milliseconds': milliseconds, 'exceptions': exception_types, 'warnings': warnings, 'exit': run.returncode}
                if variant == 'fixed':
                    assert run.returncode == 0 and actual == 50_000 and not exception_types and not warnings, result
                runs.append(result)
                print(f'Load {variant} run {n}: counted={actual}; exceptions={exception_types}; warnings={len(warnings)}; time={milliseconds} ms', flush=True)
            RESULTS['part4b'] = dict(stages, **{variant: runs})
            save()
        stages[variant] = runs
    RESULTS['part4b'] = stages


def pool_test():
    with server('submission', 'chat.ChatServer', 'part5') as (_, log):
        hold = subprocess.Popen([JAVA, '-cp', str(ROOT / 'submission/target/classes'), 'chat.LoadTester', '--clients', '12', '--hold'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        peer = None
        try:
            connected = lambda: re.findall(r'\b(hold\d+) connected from', log.read_text())
            wait_for(lambda: len(connected()) == 10)
            time.sleep(0.5)
            before = connected()
            assert len(before) == 10
            peer = Peer()
            peer.send('WaitingClient')
            peer.send('/list')
            queued = peer.quiet(0.5)
            assert queued
            output, _ = hold.communicate('\n', timeout=15)
            assert hold.returncode == 0
            replies = peer.until(lambda line: line.startswith('online: '), timeout=10)
            assert 'WaitingClient' in replies[-1]
            wait_for(lambda: len(connected()) == 12)
            peer.send('/quit')
            RESULTS['part5'] = {'passed': True, 'tcp_connections': 12, 'handlers_started_before_release': len(before), 'extra_client_initially_queued': queued, 'handlers_started_after_release': len(connected()), 'reply_after_release': replies[-1], 'hold_exit': hold.returncode}
            (EVIDENCE / 'part5-hold-client.log').write_text(output)
            print('Part 5: ten active handlers; queued clients served after release', flush=True)
        finally:
            if peer:
                peer.close()
            if hold.poll() is None:
                hold.kill()
                hold.communicate()


def failure_test():
    peers = []
    victim = None
    transcript = []
    with server('submission', 'chat.ChatServer', 'part6') as (process, log):
        try:
            for name in ['Alice', 'Bob']:
                peer = Peer()
                peers.append(peer)
                peer.send(name)
                peer.until(lambda line, name=name: line == '* ' + name + ' joined')
            victim = subprocess.Popen([JAVA, '-cp', str(ROOT / 'submission/target/classes'), 'chat.ChatClient', 'localhost', '5000', 'CrashClient'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            peers[0].until(lambda line: line == '* CrashClient joined')
            victim.kill()  # abrupt process death, without /quit
            output, _ = victim.communicate(timeout=5)
            for peer in peers:
                transcript.extend(peer.until(lambda line: line == '* CrashClient left'))
            peers[0].send('/list')
            lines = peers[0].until(lambda line: line.startswith('online: '))
            assert lines[-1] == 'online: Alice, Bob'
            transcript.extend(lines)
            peers[0].send('still connected')
            for peer in peers:
                transcript.extend(peer.until(lambda line: line == '[Alice] still connected'))
            process.terminate()
            process.wait(timeout=5)
            closed = []
            for peer in peers:
                try:
                    peer.line()
                    closed.append(False)
                except (EOFError, ConnectionResetError):
                    closed.append(True)
            assert all(closed)
            # Observe provided ChatClient behavior when the server stops.
            RESULTS['part6'] = {'passed': True, 'victim_exit': victim.returncode, 'departure_seen_by_both_survivors': True, 'list_after_crash': lines[-1], 'survivors_still_chat': True, 'server_stop_closes_survivor_connections': all(closed)}
            (EVIDENCE / 'part6-crashed-client.log').write_text(output)
        finally:
            if victim and victim.poll() is None:
                victim.kill()
                victim.communicate()
            for peer in peers:
                peer.close()
    with server('submission', 'chat.ChatServer', 'part6-client-server-stop') as (process, log):
        client = subprocess.Popen([JAVA, '-cp', str(ROOT / 'submission/target/classes'), 'chat.ChatClient', 'localhost', '5000', 'StopObserver'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        try:
            wait_for(lambda: 'StopObserver connected from' in log.read_text())
            process.terminate()
            process.wait(timeout=5)
            client.wait(timeout=5)
            output, _ = client.communicate(timeout=5)
            assert '-- disconnected from server --' in output
            RESULTS['part6']['provided_client_detects_server_stop'] = True
            (EVIDENCE / 'part6-server-stopped-client.log').write_text(output)
        finally:
            if client.poll() is None:
                client.kill()
                client.communicate()
    (EVIDENCE / 'part6-transcript.txt').write_text('\n'.join(transcript) + '\n')
    print('Part 6: abrupt process death, cleanup, continued chat and server shutdown verified', flush=True)


def save():
    (EVIDENCE / 'results.json').write_text(json.dumps(RESULTS, indent=2) + '\n')


if __name__ == '__main__':
    try:
        echo_tests()
        save()
        chat_tests()
        save()
        counter_tests()
        save()
        load_tests()
        save()
        pool_test()
        save()
        failure_test()
        save()
        print('All required experiments completed.', flush=True)
    except Exception:
        save()
        raise
