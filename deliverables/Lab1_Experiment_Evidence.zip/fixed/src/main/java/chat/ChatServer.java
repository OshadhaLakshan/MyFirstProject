package chat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Multithreaded chat server: one thread per connected client.
 *
 * Run: chat.ChatServer [port]   (default port 5000)
 */
public class ChatServer {

    public static final int DEFAULT_PORT = 5000;

    // ---- Shared state, used by ALL client threads ----------------------------
    // Part 4: safe snapshot iteration and atomic message counting.
    static List<ClientHandler> clients = new CopyOnWriteArrayList<>();
    static final AtomicInteger messageCount = new AtomicInteger(0);
    // ---------------------------------------------------------------------------

    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        try (ServerSocket server = new ServerSocket(port)) {
            log("Chat server listening on port " + port);

            while (true) {
                Socket socket = server.accept();
                ClientHandler handler = new ClientHandler(socket);

                // Part 5: replace this line with a fixed thread pool of 10 threads.
                new Thread(handler).start();
            }
        }
    }

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    /** Prints a time-stamped line to the server console. */
    static void log(String msg) {
        System.out.println(LocalTime.now().format(TIME) + "  " + msg);
    }
}
